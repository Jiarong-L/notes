module.exports = {
    a:1,
    b:2
}


