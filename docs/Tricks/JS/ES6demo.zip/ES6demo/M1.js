export const str1 = 'M1'
export function FuncM1 () {
    console.log('FuncM1')
}
export default {
    name: 'M1 Name'
}