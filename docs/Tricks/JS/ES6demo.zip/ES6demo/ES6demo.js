

// {
//     var myNum = 8
//     // let myNum = 8
//     // const myNum = 8
// }

// console.log(myNum)





// const str1 = 'abc'
// const str2 = `def
// ${str1}
// `
// console.log(str2)




// const [a,b,c,...restVar] = [1,2,3,4,5,6]
// console.log(a,b,c,restVar)



// const {user,No:Number,...restInfo} = {
//     user: 'U1',
//     No: '001',
//     depart: 'D1',
//     site: 'SH'
// }
// console.log(user,Number,restInfo)




// arr1 = [1,2,3]
// arr2 = [4,5,6]
// arr3 = [...arr1,...arr2,7,8,9]
// console.log(arr3)




// obj1 = {a:1}
// obj2 = {b:2}
// obj3 = {
//     c:3,
//     ...obj1,
//     ...obj2
// }
// console.log(obj3)
// obj3.a = 100
// console.log(obj1)



// function fn () {
//     console.log(arguments)
//     //arguments.forEach( (item) => {console.log(item)})  // 伪数组，不能执行
//     Array.from(arguments).forEach( (item) => {console.log(item)})
// }
// fn(1,2,3)







// objA = {a:1}
// objB = {b:2}
// objC = {c:3}
// objAll = Object.assign({},objA,objB,objC)

// objA.a = 100  
// console.log(objAll)




// objA = {a:{Aa:1}}
// objB = {b:2}
// objC = {c:3}
// objAll = Object.assign({},objA,objB,objC)

// objA.a.Aa = 100  
// console.log(objAll)






// class A {
//     constructor (var1,var2) {
//         this.var1 = var1
//         this.var2 = var2
//     }
//     logVar1() {
//         console.log(this.var1)
//     }
//     logVarAll() {
//         console.log(this.var1,this.var2)
//     }
// }

// class B extends A {
//     constructor (var1,var2,var3){
//         super(var1,var2)
//         this.var3 = var3
//     }
//     logVarAll() {
//         console.log(this.var1,this.var2,this.var3)
//     }
// }

// const b1 = new B('aa','bb','cc')
// b1.logVar1()
// b1.logVarAll()





// function onSucc () {console.log('Succ')}
// function onFail () {console.log('Fail')}

// const p1 = Promise.resolve()
// .then(onSucc).then(onSucc).then(onSucc).catch(onFail)

// const p2 = Promise.reject()
// .then(onSucc).then(onSucc).then(onSucc).catch(onFail)







// function onSucc () {
//     console.log('Succ')
//     return Promise.reject()
// }
// function onFail () {
//     console.log('Fail')
//     return Promise.resolve()
// }

// const p1 = Promise.reject().then(onSucc).then(onSucc).then(onSucc).catch(onFail)
// const p2 = Promise.reject().then(onSucc,onFail).then(onSucc,onFail).then(onSucc,onFail).catch(onFail)





// function asyncTask () {
//     console.log('Doing asyncTask')
//     setTimeout(() => {console.log('Finish asyncTask')}, 2000)
// }

// async function asyncMain () {
//     console.log('Start asyncMain')
//     asyncTask()  //await asyncTask() doesn't waiting!!
//     asyncTask()  //await asyncTask() doesn't waiting!!
//     console.log('End asyncMain')
// }
// p1 = asyncMain() 





// // 1.准备一个返回Promise对象的函数
// function asyncTask (ms) {
//     console.log('Doing asyncTask' + ms)
//     return new Promise((resolve) => {setTimeout(() => {resolve('Succ asyncTask' + ms)}, ms)})
// }

// // 2. async + await
// async function asyncMain () {
//     console.log('Start asyncMain')
//     console.log(await asyncTask(6000))
//     console.log(await asyncTask(1000))
//     console.log('End asyncMain')
// }
// asyncMain()




// const handler = {
//     get: function (obj, prop){return obj[prop]},
//     set: function (obj, prop, val){obj[prop]=val}
// }
// const myobj = {a:'a'}
// const p1 = new Proxy(myobj, handler)

// console.log(p1.a)       //a
// p1.a = 'b'
// console.log(myobj.a)    //b
// myobj.a = 'c'
// console.log(p1.a)       //c




import xxxDefault from './M1.js'
import {str1,FuncM1} from './M1.js'
console.log(xxxDefault)



// const moduleM2 = require('./M2')
// console.log(moduleM2)

