



var myNum = 8
var myStr = "5"
var myBool = true 
var myNull = null
var myUndefined
var myObj = {
    name: "ObjName",
    value: "ObjValue"
}

var mySum = 2/1 - 2 * 3 % 4
var myStrConcate = "Ab" + "Cd"
var aTrue = 2>1
var aFalse = 2 === "2"


if (false) {
    console.log('case1')
} else if (false) {
    console.log('case2')
} else if (false) {
    console.log('case3')
} else {
    console.log('case4')
}


for (var i=0; i<10; i++) {
    console.log(i)
}
for (var k in myObj) {
    console.log(k,myObj[k])
}


function myFunc (a,b) {
    return a + b
}
var myFuncRes = myFunc(1,'2')
console.log(myFuncRes)



var myArr = [1,2,3,4,5]
myArr.push(100)          // add to end
myArr.unshift(100)       // add to start
myArr.forEach(function (value,index) {
    console.log(value,index)
})
console.log(myArr.length)
console.log(myArr[0])

// console.log(myStrConcate)





