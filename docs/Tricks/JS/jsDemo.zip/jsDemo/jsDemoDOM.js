

// var myCollection = document.getElementsByTagName('p')
// var myCollection = document.querySelectorAll('p')
// var myCollection = document.querySelectorAll('#myblockid')
// var myCollection = document.querySelectorAll('.myclass')
// var myCollection = document.querySelectorAll('p.myclass')
// console.log(myCollection)



// var myDOM = document.querySelector('div.myclass p')
var myDOM = document.querySelector('p.myclass')

// myDOM.parentNode.textContent = 'parent'
// myDOM.previousElementSibling.firstChild.textContent = 'prev Child'
myDOM.previousElementSibling.textContent = 'prevSib'
myDOM.nextElementSibling.textContent = 'nextSib'

console.log(myDOM)
console.log(myDOM.textContent)
console.log(myDOM.childNodes)



myDOM.style.color = 'red'
// myDOM.style.backgroundColor = 'blue'   
myDOM.className = 'newClass'



// myDOM.onclick = () => {alert('clicked! 1')}
// myDOM.onclick = () => {alert('clicked! 2')}


// myDOM.addEventListener('click', () => {alert('clicked! 1')})
// myDOM.addEventListener('click', () => {alert('clicked! 2')})



setTimeout( () => {console.log('timeout')},2000 )
var myTimer = setInterval( () => {console.log('timeInterval')},2000 )


setTimeout(()=>{clearInterval(myTimer)},6000)

